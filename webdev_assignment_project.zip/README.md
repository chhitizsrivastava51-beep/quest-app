# WebDev Assignment - Fullstack Starter Project
This project contains a Flask backend and a minimal React frontend to satisfy:
- Landing page, Login/Signup (JWT)
- Blog module (local JSON storage)
- PDF summarizer (HuggingFace example)
- Google scraping (heuristic)
See backend/README_BACKEND.md and frontend/README_FRONTEND.md for details.

NOTE: This project was generated based on the assignment PDF provided by the user. fileciteturn0file0
