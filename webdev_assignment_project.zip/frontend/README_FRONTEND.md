Frontend (Vite + React) README
-----------------------------
- Install:
    npm install
- Run dev:
    npm run dev
- Build:
    npm run build
