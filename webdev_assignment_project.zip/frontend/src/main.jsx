import React from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom'
import Home from './pages/Home'
import Login from './pages/Login'
import Blogs from './pages/Blogs'
import PdfSummary from './pages/PdfSummary'
import GoogleScraper from './pages/GoogleScraper'
import './styles.css'

function App(){
  return (
    <BrowserRouter>
      <nav>
        <Link to='/'>Home</Link> | <Link to='/blogs'>Blogs</Link> | <Link to='/pdf'>PDF</Link> | <Link to='/scraper'>Scraper</Link> | <Link to='/login'>Login</Link>
      </nav>
      <Routes>
        <Route path='/' element={<Home/>} />
        <Route path='/login' element={<Login/>} />
        <Route path='/blogs' element={<Blogs/>} />
        <Route path='/pdf' element={<PdfSummary/>} />
        <Route path='/scraper' element={<GoogleScraper/>} />
      </Routes>
    </BrowserRouter>
  )
}

createRoot(document.getElementById('root')).render(<App />)
