import React, {useState} from 'react'
import { api } from '../api'
export default function GoogleScraper(){
  const [q, setQ] = useState(''); const [resu, setResu] = useState([])
  const search = async ()=> {
    const res = await api.get(`/api/scrape?q=${encodeURIComponent(q)}`)
    setResu(res.data.results || [])
  }
  return (
    <div style={{padding:20}}>
      <h2>Google Scraper (heuristic)</h2>
      <input value={q} onChange={e=>setQ(e.target.value)} placeholder='keyword' />
      <button onClick={search}>Search</button>
      <div>
        {resu.map((r,i)=> <div key={i}><a href={r.link} target='_blank' rel='noreferrer'>{r.title}</a></div>)}
      </div>
    </div>
  )
}
