import React, {useState} from 'react'
import { api } from '../api'
export default function PdfSummary(){
  const [summary, setSummary] = useState('')
  const upload = async (e) => {
    const f = new FormData()
    f.append('pdf', e.target.files[0])
    try {
      const res = await api.post('/api/pdf/summary', f, { headers: {'Content-Type':'multipart/form-data'} })
      setSummary(res.data.summary)
    } catch (err){
      setSummary('Error: ' + (err.response?.data?.msg || err.message))
    }
  }
  return (
    <div style={{padding:20}}>
      <h2>PDF Summarizer</h2>
      <input type='file' onChange={upload} />
      <pre style={{whiteSpace:'pre-wrap', marginTop:12}}>{summary}</pre>
    </div>
  )
}
