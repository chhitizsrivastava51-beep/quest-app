import React from 'react'
import { api, setToken } from '../api'

export default function Login(){
  const submit = async (e) => {
    e.preventDefault()
    const data = { email: e.target.email.value, password: e.target.password.value }
    try {
      const res = await api.post('/auth/login', data)
      setToken(res.data.token)
      alert('Login success (token set). Now use protected endpoints.')
    } catch (err){
      alert('Login failed: ' + (err.response?.data?.msg || err.message))
    }
  }

  return (
    <form onSubmit={submit} style={{padding:20}}>
      <input name='email' placeholder='email' /><br/>
      <input name='password' placeholder='password' type='password' /><br/>
      <button>Login</button>
    </form>
  )
}
