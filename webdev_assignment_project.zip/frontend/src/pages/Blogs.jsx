import React, {useEffect, useState} from 'react'
import { api } from '../api'

export default function Blogs(){
  const [blogs, setBlogs] = useState([])
  useEffect(()=>{ api.get('/api/blogs').then(r=>setBlogs(r.data)).catch(()=>{}) }, [])
  return (
    <div style={{padding:20}}>
      <h2>Blogs</h2>
      {blogs.map(b=>(
        <div key={b.id} style={{border:'1px solid #ccc', margin:8, padding:8}}>
          <h3>{b.title}</h3>
          <small>{b.date}</small>
          <p>{b.content}</p>
        </div>
      ))}
    </div>
  )
}
