import React from 'react'
export default function Home(){
  return (
    <div style={{padding:20}}>
      <h1>Landing Page</h1>
      <p>Welcome — Blog, PDF Summarizer, Google Scraper</p>
    </div>
  )
}
