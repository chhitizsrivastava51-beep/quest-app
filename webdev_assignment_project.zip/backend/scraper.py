from flask import Blueprint, request, jsonify
import requests
from bs4 import BeautifulSoup

scraper_bp = Blueprint("scraper", __name__)

@scraper_bp.get("/scrape")
def scrape():
    q = request.args.get("q", "")
    if not q:
        return jsonify({"results": []})
    url = f"https://www.google.com/search?q={requests.utils.requote_uri(q)}"
    headers = {"User-Agent": "Mozilla/5.0"}
    page = requests.get(url, headers=headers, timeout=10)
    soup = BeautifulSoup(page.text, "html.parser")

    results = []
    # Try to extract search results: Google structure can change; we use h3 anchors as heuristic.
    for r in soup.select("h3")[:10]:
        parent = r.find_parent("a")
        link = parent['href'] if parent and parent.has_attr('href') else None
        title = r.get_text(strip=True)
        results.append({"title": title, "link": link})
    return jsonify({"results": results})
