from flask import Blueprint, request, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from flask_jwt_extended import create_access_token
import json, os

auth_bp = Blueprint("auth", __name__)
USERS_FILE = "users.json"

if not os.path.exists(USERS_FILE):
    with open(USERS_FILE, "w") as f:
        json.dump([], f)

@auth_bp.post("/signup")
def signup():
    data = request.json
    with open(USERS_FILE) as f:
        users = json.load(f)

    if any(u["email"] == data["email"] for u in users):
        return {"msg": "User already exists"}, 400

    users.append({
        "email": data["email"],
        "password": generate_password_hash(data["password"])
    })
    with open(USERS_FILE, "w") as f:
        json.dump(users, f)

    return {"msg": "Signup successful"}

@auth_bp.post("/login")
def login():
    data = request.json
    with open(USERS_FILE) as f:
        users = json.load(f)

    for user in users:
        if user["email"] == data["email"] and check_password_hash(user["password"], data["password"]):
            token = create_access_token(identity=data["email"])
            return {"token": token}

    return {"msg": "Invalid credentials"}, 400
