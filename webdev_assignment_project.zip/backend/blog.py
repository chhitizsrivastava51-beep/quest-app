from flask import Blueprint, request, jsonify
import json, os
from flask_jwt_extended import jwt_required

blog_bp = Blueprint("blog", __name__)
BLOG_FILE = "blogs.json"

if not os.path.exists(BLOG_FILE):
    with open(BLOG_FILE, "w") as f:
        json.dump([], f)

@blog_bp.get("/blogs")
def get_blogs():
    with open(BLOG_FILE) as f:
        return jsonify(json.load(f))

@blog_bp.post("/blogs")
@jwt_required()
def create_blog():
    data = request.json
    with open(BLOG_FILE) as f:
        blogs = json.load(f)

    new_blog = {
        "id": len(blogs) + 1,
        "title": data.get("title"),
        "content": data.get("content"),
        "date": data.get("date")
    }
    blogs.append(new_blog)

    with open(BLOG_FILE, "w") as f:
        json.dump(blogs, f)

    return jsonify(new_blog)
