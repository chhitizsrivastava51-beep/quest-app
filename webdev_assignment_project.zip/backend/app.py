from flask import Flask
from flask_cors import CORS
from flask_jwt_extended import JWTManager
from auth import auth_bp
from blog import blog_bp
from pdf_tools import pdf_bp
from scraper import scraper_bp

app = Flask(__name__)
CORS(app)
app.config["JWT_SECRET_KEY"] = "change_this_secret_in_production"
JWTManager(app)

app.register_blueprint(auth_bp, url_prefix="/auth")
app.register_blueprint(blog_bp, url_prefix="/api")
app.register_blueprint(pdf_bp, url_prefix="/api")
app.register_blueprint(scraper_bp, url_prefix="/api")

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
