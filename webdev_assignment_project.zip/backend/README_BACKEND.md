Backend (Flask) README
----------------------
- Run locally:
    pip install -r requirements.txt
    export FLASK_APP=app.py
    export FLASK_ENV=development
    flask run
- Or directly:
    python app.py

- Default users.json and blogs.json are present for local storage.
- Protect JWT secret and HF token via environment variables in production.
