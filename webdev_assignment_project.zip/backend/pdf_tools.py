import fitz
import requests
from flask import Blueprint, request, jsonify, current_app
from flask_jwt_extended import jwt_required
import os

pdf_bp = Blueprint("pdf", __name__)

# NOTE: This uses HuggingFace inference endpoint as an example.
# Set HF_API_URL and HF_TOKEN in environment variables if you want to use a private token.
HF_API_URL = os.environ.get("HF_API_URL", "https://api-inference.huggingface.co/models/google/flan-t5-small")
HF_TOKEN = os.environ.get("HF_TOKEN", "")

def summarize_text(text):
    # Keep prompt size reasonable for free endpoints; chunk if needed.
    payload = {"inputs": "Summarize:\n\n" + text[:3000]}
    headers = {"Authorization": f"Bearer {HF_TOKEN}"} if HF_TOKEN else {}
    resp = requests.post(HF_API_URL, headers=headers, json=payload, timeout=30)
    try:
        data = resp.json()
        # Different HF models may return different shapes; try to extract text safely
        if isinstance(data, dict) and data.get('error'):
            return "Summarization request failed: " + data.get('error')
        if isinstance(data, list) and 'summary_text' in data[0]:
            return data[0]['summary_text']
        if isinstance(data, dict) and 'generated_text' in data:
            return data['generated_text']
        # fallback
        return str(data)[:800]
    except Exception as e:
        return f"Error parsing summarization response: {e}"

@pdf_bp.post("/pdf/summary")
@jwt_required()
def pdf_summary():
    if "pdf" not in request.files:
        return jsonify({"msg": "No PDF uploaded"}), 400
    file = request.files["pdf"]
    doc = fitz.open(stream=file.read(), filetype="pdf")
    text = ""
    for page in doc:
        text += page.get_text()
    if not text.strip():
        return jsonify({"msg": "No extractable text found in PDF"}), 400
    summary = summarize_text(text)
    return jsonify({"summary": summary})
